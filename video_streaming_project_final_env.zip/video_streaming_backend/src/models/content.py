from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

# Import db from user model
from src.models.user import db

class Language(db.Model):
    __tablename__ = 'languages'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    code = db.Column(db.String(5), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

class Genre(db.Model):
    __tablename__ = 'genres'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    slug = db.Column(db.String(50), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

class CastCrew(db.Model):
    __tablename__ = 'cast_crew'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.Enum('actor', 'director', 'producer'), nullable=False)
    bio = db.Column(db.Text)
    image = db.Column(db.String(255))
    birth_date = db.Column(db.Date)

class Content(db.Model):
    __tablename__ = 'content'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    poster_image = db.Column(db.String(255))
    banner_image = db.Column(db.String(255))
    trailer_url = db.Column(db.String(255))
    content_type = db.Column(db.Enum('movie', 'show', 'sport', 'live_tv'), nullable=False)
    language_id = db.Column(db.Integer, db.ForeignKey('languages.id'))
    is_premium = db.Column(db.Boolean, default=False)
    view_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    language = db.relationship('Language', backref='content')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'slug': self.slug,
            'description': self.description,
            'poster_image': self.poster_image,
            'banner_image': self.banner_image,
            'trailer_url': self.trailer_url,
            'content_type': self.content_type,
            'language_id': self.language_id,
            'is_premium': self.is_premium,
            'view_count': self.view_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Movie(db.Model):
    __tablename__ = 'movies'
    
    id = db.Column(db.Integer, primary_key=True)
    content_id = db.Column(db.Integer, db.ForeignKey('content.id'), nullable=False)
    video_url = db.Column(db.String(255))
    duration = db.Column(db.Integer)  # in minutes
    release_date = db.Column(db.Date)
    imdb_rating = db.Column(db.Float)
    age_rating = db.Column(db.String(10))
    
    # Relationships
    content = db.relationship('Content', backref='movie_details')
    
    def to_dict(self):
        content_dict = self.content.to_dict() if self.content else {}
        content_dict.update({
            'video_url': self.video_url,
            'duration': self.duration,
            'release_date': self.release_date.isoformat() if self.release_date else None,
            'imdb_rating': self.imdb_rating,
            'age_rating': self.age_rating
        })
        return content_dict

class TVShow(db.Model):
    __tablename__ = 'tv_shows'
    
    id = db.Column(db.Integer, primary_key=True)
    content_id = db.Column(db.Integer, db.ForeignKey('content.id'), nullable=False)
    total_seasons = db.Column(db.Integer)
    total_episodes = db.Column(db.Integer)
    release_date = db.Column(db.Date)
    imdb_rating = db.Column(db.Float)
    age_rating = db.Column(db.String(10))
    
    # Relationships
    content = db.relationship('Content', backref='show_details')
    episodes = db.relationship('Episode', backref='show', lazy=True)

class Episode(db.Model):
    __tablename__ = 'episodes'
    
    id = db.Column(db.Integer, primary_key=True)
    show_id = db.Column(db.Integer, db.ForeignKey('tv_shows.id'), nullable=False)
    season_number = db.Column(db.Integer, nullable=False)
    episode_number = db.Column(db.Integer, nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    video_url = db.Column(db.String(255))
    duration = db.Column(db.Integer)  # in minutes
    is_premium = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Sport(db.Model):
    __tablename__ = 'sports'
    
    id = db.Column(db.Integer, primary_key=True)
    content_id = db.Column(db.Integer, db.ForeignKey('content.id'), nullable=False)
    video_url = db.Column(db.String(255))
    sport_type = db.Column(db.String(50))
    event_date = db.Column(db.DateTime)
    duration = db.Column(db.Integer)  # in minutes
    
    # Relationships
    content = db.relationship('Content', backref='sport_details')

class LiveTV(db.Model):
    __tablename__ = 'live_tv'
    
    id = db.Column(db.Integer, primary_key=True)
    content_id = db.Column(db.Integer, db.ForeignKey('content.id'), nullable=False)
    stream_url = db.Column(db.String(255))
    category = db.Column(db.String(50))
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    content = db.relationship('Content', backref='live_tv_details')

# Association tables for many-to-many relationships
movie_genres = db.Table('movie_genres',
    db.Column('movie_id', db.Integer, db.ForeignKey('movies.id'), primary_key=True),
    db.Column('genre_id', db.Integer, db.ForeignKey('genres.id'), primary_key=True)
)

movie_cast = db.Table('movie_cast',
    db.Column('movie_id', db.Integer, db.ForeignKey('movies.id'), primary_key=True),
    db.Column('cast_id', db.Integer, db.ForeignKey('cast_crew.id'), primary_key=True),
    db.Column('role', db.String(100))
)

show_genres = db.Table('show_genres',
    db.Column('show_id', db.Integer, db.ForeignKey('tv_shows.id'), primary_key=True),
    db.Column('genre_id', db.Integer, db.ForeignKey('genres.id'), primary_key=True)
)

show_cast = db.Table('show_cast',
    db.Column('show_id', db.Integer, db.ForeignKey('tv_shows.id'), primary_key=True),
    db.Column('cast_id', db.Integer, db.ForeignKey('cast_crew.id'), primary_key=True),
    db.Column('role', db.String(100))
)

