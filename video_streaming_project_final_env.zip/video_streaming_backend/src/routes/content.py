from flask import Blueprint, request, jsonify
from src.models.content import db, Content, Movie, TVShow, Episode, Sport, LiveTV, Genre, Language
from src.models.user import Watchlist, WatchHistory
import random

content_bp = Blueprint('content', __name__)

@content_bp.route('/movies', methods=['GET'])
def get_movies():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        genre = request.args.get('genre')
        language = request.args.get('language')
        sort_by = request.args.get('sort_by', 'newest')
        search = request.args.get('search')
        
        # Base query
        query = db.session.query(Content, Movie).join(Movie, Content.id == Movie.content_id)
        query = query.filter(Content.content_type == 'movie')
        
        # Apply filters
        if genre and genre != 'all':
            # In a real app, you'd join with genres table
            pass
        
        if language and language != 'all':
            query = query.join(Language).filter(Language.name == language)
        
        if search:
            query = query.filter(Content.title.contains(search))
        
        # Apply sorting
        if sort_by == 'newest':
            query = query.order_by(Movie.release_date.desc())
        elif sort_by == 'oldest':
            query = query.order_by(Movie.release_date.asc())
        elif sort_by == 'rating':
            query = query.order_by(Movie.imdb_rating.desc())
        elif sort_by == 'title':
            query = query.order_by(Content.title.asc())
        
        # Paginate
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        
        # Generate mock data if no real data exists
        if not pagination.items:
            movies = generate_mock_movies(per_page)
            return jsonify({
                'movies': movies,
                'total': len(movies),
                'page': page,
                'per_page': per_page,
                'pages': 1
            }), 200
        
        movies = []
        for content, movie in pagination.items:
            movie_dict = movie.to_dict()
            movies.append(movie_dict)
        
        return jsonify({
            'movies': movies,
            'total': pagination.total,
            'page': page,
            'per_page': per_page,
            'pages': pagination.pages
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@content_bp.route('/tv-shows', methods=['GET'])
def get_tv_shows():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Generate mock data
        shows = generate_mock_tv_shows(per_page)
        
        return jsonify({
            'shows': shows,
            'total': len(shows),
            'page': page,
            'per_page': per_page,
            'pages': 1
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@content_bp.route('/sports', methods=['GET'])
def get_sports():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 16, type=int)
        
        # Generate mock data
        sports = generate_mock_sports(per_page)
        
        return jsonify({
            'sports': sports,
            'total': len(sports),
            'page': page,
            'per_page': per_page,
            'pages': 1
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@content_bp.route('/live-tv', methods=['GET'])
def get_live_tv():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        # Generate mock data
        channels = generate_mock_live_tv(per_page)
        
        return jsonify({
            'channels': channels,
            'total': len(channels),
            'page': page,
            'per_page': per_page,
            'pages': 1
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@content_bp.route('/featured', methods=['GET'])
def get_featured_content():
    try:
        # Generate mock featured content
        featured = [
            {
                'id': 1,
                'title': 'فيلم الأكشن الجديد',
                'description': 'مغامرة مثيرة مليئة بالأكشن والإثارة في عالم مليء بالتحديات والمخاطر. تابع البطل في رحلته الشاقة للوصول إلى هدفه.',
                'poster_image': '/api/placeholder/400/600',
                'banner_image': '/api/placeholder/1200/600',
                'rating': 8.5,
                'year': 2024,
                'duration': '2h 15m',
                'genre': 'أكشن، مغامرة',
                'is_premium': True,
                'content_type': 'movie'
            },
            {
                'id': 2,
                'title': 'مسلسل الدراما الشهير',
                'description': 'قصة درامية مؤثرة تحكي عن الحياة والحب والصراعات الإنسانية في عالم معقد ومتغير.',
                'poster_image': '/api/placeholder/400/600',
                'banner_image': '/api/placeholder/1200/600',
                'rating': 9.2,
                'year': 2024,
                'duration': '45m',
                'genre': 'دراما، رومانسي',
                'is_premium': False,
                'content_type': 'show'
            }
        ]
        
        return jsonify({'featured': featured}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@content_bp.route('/genres', methods=['GET'])
def get_genres():
    try:
        genres = [
            {'id': 1, 'name': 'أكشن', 'slug': 'action'},
            {'id': 2, 'name': 'دراما', 'slug': 'drama'},
            {'id': 3, 'name': 'كوميديا', 'slug': 'comedy'},
            {'id': 4, 'name': 'رعب', 'slug': 'horror'},
            {'id': 5, 'name': 'خيال علمي', 'slug': 'sci-fi'},
            {'id': 6, 'name': 'رومانسي', 'slug': 'romance'},
            {'id': 7, 'name': 'إثارة', 'slug': 'thriller'},
            {'id': 8, 'name': 'مغامرة', 'slug': 'adventure'}
        ]
        
        return jsonify({'genres': genres}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@content_bp.route('/languages', methods=['GET'])
def get_languages():
    try:
        languages = [
            {'id': 1, 'name': 'العربية', 'code': 'ar'},
            {'id': 2, 'name': 'الإنجليزية', 'code': 'en'},
            {'id': 3, 'name': 'الفرنسية', 'code': 'fr'},
            {'id': 4, 'name': 'الإسبانية', 'code': 'es'},
            {'id': 5, 'name': 'التركية', 'code': 'tr'}
        ]
        
        return jsonify({'languages': languages}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Helper functions to generate mock data
def generate_mock_movies(count):
    movies = []
    genres = ['أكشن', 'دراما', 'كوميديا', 'رعب', 'خيال علمي']
    languages = ['العربية', 'الإنجليزية', 'الفرنسية']
    
    for i in range(1, count + 1):
        movie = {
            'id': i,
            'title': f'فيلم {i}',
            'description': f'وصف الفيلم {i}',
            'poster_image': '/api/placeholder/300/450',
            'banner_image': '/api/placeholder/1200/600',
            'rating': round(random.uniform(7.0, 10.0), 1),
            'year': random.randint(2020, 2024),
            'duration': f'{random.randint(90, 180)}m',
            'genre': random.choice(genres),
            'language': random.choice(languages),
            'is_premium': random.choice([True, False]),
            'content_type': 'movie'
        }
        movies.append(movie)
    
    return movies

def generate_mock_tv_shows(count):
    shows = []
    genres = ['دراما', 'كوميديا', 'إثارة', 'خيال علمي', 'تاريخي']
    
    for i in range(1, count + 1):
        show = {
            'id': i,
            'title': f'مسلسل {i}',
            'description': f'وصف المسلسل {i}',
            'poster_image': '/api/placeholder/300/450',
            'rating': round(random.uniform(7.0, 10.0), 1),
            'year': random.randint(2020, 2024),
            'duration': f'{random.randint(30, 60)}m',
            'genre': random.choice(genres),
            'is_premium': random.choice([True, False]),
            'content_type': 'show'
        }
        shows.append(show)
    
    return shows

def generate_mock_sports(count):
    sports = []
    sport_types = ['كرة القدم', 'كرة السلة', 'التنس', 'السباحة', 'الجري']
    
    for i in range(1, count + 1):
        sport = {
            'id': i,
            'title': f'محتوى رياضي {i}',
            'description': f'وصف المحتوى الرياضي {i}',
            'poster_image': '/api/placeholder/300/450',
            'rating': round(random.uniform(7.0, 10.0), 1),
            'year': 2024,
            'duration': f'{random.randint(60, 120)}m',
            'genre': random.choice(sport_types),
            'is_premium': random.choice([True, False]),
            'content_type': 'sport'
        }
        sports.append(sport)
    
    return sports

def generate_mock_live_tv(count):
    channels = []
    categories = ['أخبار', 'ترفيه', 'رياضة', 'أطفال', 'وثائقي']
    
    for i in range(1, count + 1):
        channel = {
            'id': i,
            'title': f'قناة {i}',
            'description': f'وصف القناة {i}',
            'poster_image': '/api/placeholder/300/200',
            'category': random.choice(categories),
            'is_live': True,
            'is_premium': random.choice([True, False]),
            'content_type': 'live_tv'
        }
        channels.append(channel)
    
    return channels

