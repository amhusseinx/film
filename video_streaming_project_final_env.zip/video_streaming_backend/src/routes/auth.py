
from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from src.models.user import db, User
import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        if not data.get('name') or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'الاسم والبريد الإلكتروني وكلمة المرور مطلوبة'}), 400

        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({'error': 'البريد الإلكتروني مستخدم بالفعل'}), 400

        password_hash = generate_password_hash(data['password'])
        new_user = User(
            name=data['name'],
            email=data['email'],
            password_hash=password_hash,
            subscription_plan_id=1
        )

        db.session.add(new_user)
        db.session.commit()

        access_token = create_access_token(identity={'id': new_user.id, 'role': new_user.role})
        return jsonify({
            'message': 'تم إنشاء الحساب بنجاح',
            'token': access_token,
            'user': new_user.to_dict()
        }), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'البريد الإلكتروني وكلمة المرور مطلوبان'}), 400

        user = User.query.filter_by(email=data['email']).first()
        if not user or not check_password_hash(user.password_hash, data['password']):
            return jsonify({'error': 'البريد الإلكتروني أو كلمة المرور غير صحيحة'}), 401

        if not user.is_active:
            return jsonify({'error': 'الحساب غير مفعل'}), 403

        access_token = create_access_token(identity={'id': user.id, 'role': user.role})
        return jsonify({
            'message': 'تم تسجيل الدخول بنجاح',
            'token': access_token,
            'user': user.to_dict()
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    user_info = get_jwt_identity()
    user_id = user_info['id']
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'المستخدم غير موجود'}), 404
    return jsonify({'user': user.to_dict()})
