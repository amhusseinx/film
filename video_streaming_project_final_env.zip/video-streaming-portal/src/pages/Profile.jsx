import React from 'react';

const Profile = () => {
  return (
    <div className="pt-16 min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">الملف الشخصي</h1>
        <p className="text-muted-foreground">قريباً...</p>
      </div>
    </div>
  );
};

export default Profile;

