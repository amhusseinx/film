import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Play, Plus, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ContentCard from '../components/ContentCard';
import ContentSlider from '../components/ContentSlider';
import heroBg from '../assets/hero-bg.jpg';

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Mock data for featured content
  const featuredContent = [
    {
      id: 1,
      title: 'فيلم الأكشن الجديد',
      description: 'مغامرة مثيرة مليئة بالأكشن والإثارة في عالم مليء بالتحديات والمخاطر. تابع البطل في رحلته الشاقة للوصول إلى هدفه.',
      image: heroBg,
      rating: 8.5,
      year: 2024,
      duration: '2h 15m',
      genre: 'أكشن، مغامرة',
      isPremium: true,
    },
    {
      id: 2,
      title: 'مسلسل الدراما الشهير',
      description: 'قصة درامية مؤثرة تحكي عن الحياة والحب والصراعات الإنسانية في عالم معقد ومتغير.',
      image: heroBg,
      rating: 9.2,
      year: 2024,
      duration: '45m',
      genre: 'دراما، رومانسي',
      isPremium: false,
    },
  ];

  // Mock data for content sections
  const latestMovies = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    title: `فيلم ${i + 1}`,
    image: heroBg,
    rating: (Math.random() * 3 + 7).toFixed(1),
    year: 2024,
    isPremium: Math.random() > 0.5,
  }));

  const latestShows = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    title: `مسلسل ${i + 1}`,
    image: heroBg,
    rating: (Math.random() * 3 + 7).toFixed(1),
    year: 2024,
    isPremium: Math.random() > 0.5,
  }));

  const sportsContent = Array.from({ length: 8 }, (_, i) => ({
    id: i + 1,
    title: `محتوى رياضي ${i + 1}`,
    image: heroBg,
    rating: (Math.random() * 3 + 7).toFixed(1),
    year: 2024,
    isPremium: Math.random() > 0.5,
  }));

  const liveTVChannels = Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    title: `قناة ${i + 1}`,
    image: heroBg,
    isLive: true,
    isPremium: Math.random() > 0.5,
  }));

  // Auto-slide for hero section
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredContent.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [featuredContent.length]);

  const currentContent = featuredContent[currentSlide];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section 
        className="hero-section"
        style={{
          backgroundImage: `url(${currentContent.image})`,
        }}
      >
        <div className="hero-gradient absolute inset-0" />
        <div className="hero-content">
          <div className="mb-4">
            <span className="genre-tag">{currentContent.genre}</span>
            {currentContent.isPremium && (
              <span className="rating-badge mr-2">
                <Star className="h-3 w-3 ml-1" />
                مميز
              </span>
            )}
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            {currentContent.title}
          </h1>
          
          <p className="text-lg md:text-xl mb-6 max-w-2xl leading-relaxed">
            {currentContent.description}
          </p>
          
          <div className="flex items-center space-x-4 mb-8">
            <span className="text-accent font-bold">⭐ {currentContent.rating}</span>
            <span>{currentContent.year}</span>
            <span>{currentContent.duration}</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button className="btn-primary text-lg px-8 py-3">
              <Play className="h-5 w-5 ml-2" />
              مشاهدة الآن
            </Button>
            <Button variant="outline" className="text-lg px-8 py-3">
              <Plus className="h-5 w-5 ml-2" />
              إضافة للقائمة
            </Button>
          </div>
        </div>
        
        {/* Hero Navigation */}
        <div className="absolute bottom-8 right-8 flex space-x-2">
          {featuredContent.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentSlide ? 'bg-primary' : 'bg-white/30'
              }`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </section>

      {/* Content Sections */}
      <div className="container mx-auto px-4 py-12 space-y-12">
        {/* Latest Movies */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title">أحدث الأفلام</h2>
            <Link to="/movies" className="text-primary hover:text-primary/80 transition-colors">
              عرض الكل
            </Link>
          </div>
          <ContentSlider items={latestMovies} />
        </section>

        {/* Latest TV Shows */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title">أحدث المسلسلات</h2>
            <Link to="/tv-shows" className="text-primary hover:text-primary/80 transition-colors">
              عرض الكل
            </Link>
          </div>
          <ContentSlider items={latestShows} />
        </section>

        {/* Sports Content */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title">المحتوى الرياضي</h2>
            <Link to="/sports" className="text-primary hover:text-primary/80 transition-colors">
              عرض الكل
            </Link>
          </div>
          <ContentSlider items={sportsContent} />
        </section>

        {/* Live TV */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title">البث المباشر</h2>
            <Link to="/live-tv" className="text-primary hover:text-primary/80 transition-colors">
              عرض الكل
            </Link>
          </div>
          <ContentSlider items={liveTVChannels} />
        </section>

        {/* Advertisement Banner */}
        <section className="my-12">
          <div className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">اشترك الآن واستمتع بمحتوى غير محدود</h3>
            <p className="text-muted-foreground mb-6">
              احصل على وصول كامل لجميع الأفلام والمسلسلات والمحتوى الرياضي
            </p>
            <Button className="btn-primary text-lg px-8 py-3">
              <Star className="h-5 w-5 ml-2" />
              اشترك الآن
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Home;

