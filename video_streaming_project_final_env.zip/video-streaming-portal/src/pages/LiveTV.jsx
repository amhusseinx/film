import React, { useState, useEffect } from 'react';
import { Radio, Tv, Volume2, Users, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import VideoPlayer from '../components/VideoPlayer';
import heroBg from '../assets/hero-bg.jpg';

const LiveTV = () => {
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [channels, setChannels] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    // Mock live TV channels data
    const mockChannels = [
      {
        id: 1,
        name: 'قناة الأخبار',
        category: 'أخبار',
        logo: heroBg,
        stream_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        current_program: 'نشرة الأخبار المسائية',
        next_program: 'برنامج حوار مفتوح',
        viewers: 125000,
        is_premium: false,
        is_live: true,
        quality: 'HD'
      },
      {
        id: 2,
        name: 'قناة الرياضة',
        category: 'رياضة',
        logo: heroBg,
        stream_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
        current_program: 'مباراة كرة القدم',
        next_program: 'أخبار الرياضة',
        viewers: 89000,
        is_premium: true,
        is_live: true,
        quality: '4K'
      },
      {
        id: 3,
        name: 'قناة الأطفال',
        category: 'أطفال',
        logo: heroBg,
        stream_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
        current_program: 'كرتون مسلي',
        next_program: 'برامج تعليمية',
        viewers: 45000,
        is_premium: false,
        is_live: true,
        quality: 'HD'
      },
      {
        id: 4,
        name: 'قناة الأفلام',
        category: 'ترفيه',
        logo: heroBg,
        stream_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        current_program: 'فيلم أكشن',
        next_program: 'فيلم كوميدي',
        viewers: 156000,
        is_premium: true,
        is_live: true,
        quality: 'HD'
      },
      {
        id: 5,
        name: 'قناة الوثائقيات',
        category: 'وثائقي',
        logo: heroBg,
        stream_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
        current_program: 'وثائقي الطبيعة',
        next_program: 'تاريخ الحضارات',
        viewers: 32000,
        is_premium: false,
        is_live: true,
        quality: 'HD'
      },
      {
        id: 6,
        name: 'قناة الموسيقى',
        category: 'ترفيه',
        logo: heroBg,
        stream_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
        current_program: 'أغاني شعبية',
        next_program: 'حفل موسيقي',
        viewers: 67000,
        is_premium: false,
        is_live: true,
        quality: 'HD'
      }
    ];

    setChannels(mockChannels);
    setSelectedChannel(mockChannels[0]);

    // Extract unique categories
    const uniqueCategories = ['الكل', ...new Set(mockChannels.map(ch => ch.category))];
    setCategories(uniqueCategories);
  }, []);

  const filteredChannels = selectedCategory === 'all' || selectedCategory === 'الكل'
    ? channels
    : channels.filter(channel => channel.category === selectedCategory);

  const handleChannelSelect = (channel) => {
    setSelectedChannel(channel);
  };

  const formatViewers = (count) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <div className="pt-16">
      {/* Page Header */}
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center space-x-4 mb-4">
            <Radio className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">البث المباشر</h1>
            <div className="flex items-center space-x-2 bg-red-600 text-white px-3 py-1 rounded-full text-sm animate-pulse">
              <div className="w-2 h-2 bg-white rounded-full"></div>
              <span>مباشر</span>
            </div>
          </div>
          <p className="text-muted-foreground">
            شاهد القنوات المباشرة على مدار الساعة
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Channel List */}
          <div className="lg:col-span-1">
            {/* Category Filter */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">الفئات</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-right px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === category || (selectedCategory === 'all' && category === 'الكل')
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted hover:bg-muted/80 text-muted-foreground'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Channels List */}
            <div className="space-y-3">
              <h3 className="font-semibold">القنوات ({filteredChannels.length})</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredChannels.map((channel) => (
                  <div
                    key={channel.id}
                    onClick={() => handleChannelSelect(channel)}
                    className={`p-3 rounded-lg cursor-pointer transition-all ${
                      selectedChannel?.id === channel.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card hover:bg-card/80 border border-border'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <img
                        src={channel.logo}
                        alt={channel.name}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium truncate">{channel.name}</h4>
                          {channel.is_live && (
                            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                          )}
                        </div>
                        <p className="text-xs opacity-70 truncate">{channel.current_program}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-xs opacity-60">{channel.category}</span>
                          <span className="text-xs opacity-60">•</span>
                          <span className="text-xs opacity-60">{channel.quality}</span>
                          {channel.is_premium && (
                            <>
                              <span className="text-xs opacity-60">•</span>
                              <span className="text-xs bg-accent text-accent-foreground px-1 rounded">مميز</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Video Player */}
          <div className="lg:col-span-3">
            {selectedChannel ? (
              <div className="space-y-6">
                {/* Player */}
                <div className="aspect-video bg-black rounded-lg overflow-hidden">
                  <VideoPlayer
                    src={selectedChannel.stream_url}
                    poster={selectedChannel.logo}
                    title={selectedChannel.name}
                    autoPlay={true}
                  />
                </div>

                {/* Channel Info */}
                <div className="bg-card rounded-lg p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <img
                        src={selectedChannel.logo}
                        alt={selectedChannel.name}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div>
                        <div className="flex items-center space-x-3 mb-2">
                          <h2 className="text-2xl font-bold">{selectedChannel.name}</h2>
                          <div className="flex items-center space-x-2 bg-red-600 text-white px-2 py-1 rounded text-sm">
                            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                            <span>مباشر</span>
                          </div>
                          {selectedChannel.is_premium && (
                            <span className="bg-accent text-accent-foreground px-2 py-1 rounded text-sm font-bold">
                              مميز
                            </span>
                          )}
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span className="flex items-center">
                            <Tv className="h-4 w-4 ml-1" />
                            {selectedChannel.category}
                          </span>
                          <span className="flex items-center">
                            <Users className="h-4 w-4 ml-1" />
                            {formatViewers(selectedChannel.viewers)} مشاهد
                          </span>
                          <span className="flex items-center">
                            <Volume2 className="h-4 w-4 ml-1" />
                            {selectedChannel.quality}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Program Schedule */}
                  <div className="border-t border-border pt-4">
                    <h3 className="font-semibold mb-3">جدول البرامج</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-primary/10 rounded-lg">
                        <div>
                          <h4 className="font-medium text-primary">الآن</h4>
                          <p className="text-sm">{selectedChannel.current_program}</p>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 inline ml-1" />
                          جاري البث
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <h4 className="font-medium">التالي</h4>
                          <p className="text-sm text-muted-foreground">{selectedChannel.next_program}</p>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 inline ml-1" />
                          21:00
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Tv className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">اختر قناة للمشاهدة</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveTV;

