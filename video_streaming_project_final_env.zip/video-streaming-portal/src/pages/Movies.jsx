import React, { useState } from 'react';
import { Filter, Search, Grid, List } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ContentCard from '../components/ContentCard';
import heroBg from '../assets/hero-bg.jpg';

const Movies = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [selectedLanguage, setSelectedLanguage] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  // Mock data for movies
  const movies = Array.from({ length: 24 }, (_, i) => ({
    id: i + 1,
    title: `فيلم ${i + 1}`,
    image: heroBg,
    rating: (Math.random() * 3 + 7).toFixed(1),
    year: 2024 - Math.floor(Math.random() * 5),
    duration: `${Math.floor(Math.random() * 60 + 90)}m`,
    genre: ['أكشن', 'دراما', 'كوميديا', 'رعب', 'خيال علمي'][Math.floor(Math.random() * 5)],
    language: ['العربية', 'الإنجليزية', 'الفرنسية'][Math.floor(Math.random() * 3)],
    isPremium: Math.random() > 0.5,
  }));

  const genres = ['الكل', 'أكشن', 'دراما', 'كوميديا', 'رعب', 'خيال علمي'];
  const languages = ['الكل', 'العربية', 'الإنجليزية', 'الفرنسية'];
  const sortOptions = [
    { value: 'newest', label: 'الأحدث' },
    { value: 'oldest', label: 'الأقدم' },
    { value: 'rating', label: 'الأعلى تقييماً' },
    { value: 'title', label: 'الاسم' },
  ];

  // Filter and sort movies
  const filteredMovies = movies
    .filter(movie => {
      const matchesSearch = movie.title.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesGenre = selectedGenre === 'all' || movie.genre === selectedGenre;
      const matchesLanguage = selectedLanguage === 'all' || movie.language === selectedLanguage;
      return matchesSearch && matchesGenre && matchesLanguage;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return b.year - a.year;
        case 'oldest':
          return a.year - b.year;
        case 'rating':
          return parseFloat(b.rating) - parseFloat(a.rating);
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

  return (
    <div className="pt-16">
      {/* Page Header */}
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">الأفلام</h1>
          <p className="text-muted-foreground">
            اكتشف مجموعة واسعة من الأفلام من جميع أنحاء العالم
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters and Search */}
        <div className="bg-card rounded-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
            {/* Search */}
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  type="text"
                  placeholder="البحث عن فيلم..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>

            {/* Genre Filter */}
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger>
                <SelectValue placeholder="النوع" />
              </SelectTrigger>
              <SelectContent>
                {genres.map((genre) => (
                  <SelectItem key={genre} value={genre === 'الكل' ? 'all' : genre}>
                    {genre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Language Filter */}
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger>
                <SelectValue placeholder="اللغة" />
              </SelectTrigger>
              <SelectContent>
                {languages.map((language) => (
                  <SelectItem key={language} value={language === 'الكل' ? 'all' : language}>
                    {language}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="ترتيب حسب" />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* View Mode and Results Count */}
          <div className="flex items-center justify-between">
            <div className="text-muted-foreground">
              عرض {filteredMovies.length} من {movies.length} فيلم
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Movies Grid */}
        {filteredMovies.length > 0 ? (
          <div className={viewMode === 'grid' 
            ? 'content-grid' 
            : 'space-y-4'
          }>
            {filteredMovies.map((movie) => (
              <div key={movie.id}>
                <ContentCard item={movie} type="movie" />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-muted-foreground text-lg mb-4">
              لم يتم العثور على أفلام تطابق البحث
            </div>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedGenre('all');
                setSelectedLanguage('all');
              }}
            >
              مسح الفلاتر
            </Button>
          </div>
        )}

        {/* Load More Button */}
        {filteredMovies.length > 0 && (
          <div className="text-center mt-12">
            <Button variant="outline" className="px-8 py-3">
              تحميل المزيد
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Movies;

