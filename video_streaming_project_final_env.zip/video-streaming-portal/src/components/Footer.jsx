import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Smartphone, Monitor } from 'lucide-react';
import logo from '../assets/logo.png';

const Footer = () => {
  const footerLinks = [
    {
      title: 'الشركة',
      links: [
        { name: 'من نحن', path: '/about' },
        { name: 'اتصل بنا', path: '/contact' },
        { name: 'الوظائف', path: '/careers' },
        { name: 'الأخبار', path: '/news' },
      ],
    },
    {
      title: 'الدعم',
      links: [
        { name: 'مركز المساعدة', path: '/help' },
        { name: 'الأسئلة الشائعة', path: '/faq' },
        { name: 'تواصل معنا', path: '/contact' },
        { name: 'الإبلاغ عن مشكلة', path: '/report' },
      ],
    },
    {
      title: 'القانونية',
      links: [
        { name: 'شروط الاستخدام', path: '/terms' },
        { name: 'سياسة الخصوصية', path: '/privacy' },
        { name: 'سياسة ملفات تعريف الارتباط', path: '/cookies' },
        { name: 'إشعار قانوني', path: '/legal' },
      ],
    },
    {
      title: 'المحتوى',
      links: [
        { name: 'الأفلام', path: '/movies' },
        { name: 'المسلسلات', path: '/tv-shows' },
        { name: 'الرياضة', path: '/sports' },
        { name: 'البث المباشر', path: '/live-tv' },
      ],
    },
  ];

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, url: '#' },
    { name: 'Twitter', icon: Twitter, url: '#' },
    { name: 'Instagram', icon: Instagram, url: '#' },
  ];

  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Logo and Description */}
          <div className="lg:col-span-1">
            <Link to="/" className="inline-block mb-4">
              <img src={logo} alt="VIDEO" className="h-8 w-auto" />
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed">
              منصة بث فيديو متكاملة لمشاهدة الأفلام والمسلسلات والمحتوى الرياضي والبث المباشر بجودة عالية.
            </p>
            
            {/* Social Media Links */}
            <div className="flex space-x-4 mt-6">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={social.name}
                    href={social.url}
                    className="text-muted-foreground hover:text-primary transition-colors duration-200"
                    aria-label={social.name}
                  >
                    <IconComponent className="h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Footer Links */}
          {footerLinks.map((section) => (
            <div key={section.title}>
              <h3 className="font-semibold text-foreground mb-4">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-muted-foreground hover:text-primary transition-colors duration-200 text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* App Download Section */}
        <div className="border-t border-border pt-8 mt-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="font-semibold text-foreground mb-2">حمل التطبيق</h3>
              <p className="text-muted-foreground text-sm">
                استمتع بالمشاهدة في أي مكان وأي وقت
              </p>
            </div>
            
            <div className="flex space-x-4">
              {/* App Store Button */}
              <a
                href="#"
                className="flex items-center space-x-3 bg-muted hover:bg-muted/80 px-4 py-2 rounded-lg transition-colors duration-200"
              >
                <Monitor className="h-6 w-6 text-foreground" />
                <div className="text-right">
                  <div className="text-xs text-muted-foreground">متوفر على</div>
                  <div className="text-sm font-semibold text-foreground">App Store</div>
                </div>
              </a>
              
              {/* Google Play Button */}
              <a
                href="#"
                className="flex items-center space-x-3 bg-muted hover:bg-muted/80 px-4 py-2 rounded-lg transition-colors duration-200"
              >
                <Smartphone className="h-6 w-6 text-foreground" />
                <div className="text-right">
                  <div className="text-xs text-muted-foreground">متوفر على</div>
                  <div className="text-sm font-semibold text-foreground">Google Play</div>
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-border pt-6 mt-6 text-center">
          <p className="text-muted-foreground text-sm">
            © 2024 بوابة بث الفيديو. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

