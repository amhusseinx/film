# تصميم موقع بث الفيديو - المواصفات التقنية والتصميم

## 1. هيكل قاعدة البيانات

### جداول المستخدمين والمصادقة
```sql
-- جدول المستخدمين
users:
- id (Primary Key)
- name (VARCHAR)
- email (VARCHAR, UNIQUE)
- password (VARCHAR, HASHED)
- profile_image (VARCHAR)
- subscription_plan_id (Foreign Key)
- device_limit (INT)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
- is_active (BOOLEAN)

-- جدول خطط الاشتراك
subscription_plans:
- id (Primary Key)
- name (VARCHAR) - Basic, Premium, Platinum, Diamond
- price (DECIMAL)
- duration_days (INT)
- device_limit (INT)
- features (JSON)
- is_active (BOOLEAN)
- created_at (TIMESTAMP)

-- جدول المعاملات المالية
transactions:
- id (Primary Key)
- user_id (Foreign Key)
- plan_id (Foreign Key)
- amount (DECIMAL)
- payment_method (VARCHAR)
- payment_gateway (VARCHAR)
- transaction_id (VARCHAR)
- status (ENUM: pending, completed, failed)
- created_at (TIMESTAMP)
```

### جداول المحتوى
```sql
-- جدول اللغات
languages:
- id (Primary Key)
- name (VARCHAR)
- code (VARCHAR) - ar, en, fr, etc.
- is_active (BOOLEAN)

-- جدول الأنواع/التصنيفات
genres:
- id (Primary Key)
- name (VARCHAR)
- slug (VARCHAR)
- is_active (BOOLEAN)

-- جدول طاقم العمل
cast_crew:
- id (Primary Key)
- name (VARCHAR)
- type (ENUM: actor, director, producer)
- bio (TEXT)
- image (VARCHAR)
- birth_date (DATE)

-- جدول الأفلام
movies:
- id (Primary Key)
- title (VARCHAR)
- slug (VARCHAR)
- description (TEXT)
- poster_image (VARCHAR)
- banner_image (VARCHAR)
- trailer_url (VARCHAR)
- video_url (VARCHAR)
- duration (INT) - in minutes
- release_date (DATE)
- imdb_rating (DECIMAL)
- age_rating (VARCHAR)
- language_id (Foreign Key)
- is_premium (BOOLEAN)
- view_count (INT)
- created_at (TIMESTAMP)

-- جدول المسلسلات
tv_shows:
- id (Primary Key)
- title (VARCHAR)
- slug (VARCHAR)
- description (TEXT)
- poster_image (VARCHAR)
- banner_image (VARCHAR)
- trailer_url (VARCHAR)
- total_seasons (INT)
- total_episodes (INT)
- release_date (DATE)
- imdb_rating (DECIMAL)
- age_rating (VARCHAR)
- language_id (Foreign Key)
- is_premium (BOOLEAN)
- view_count (INT)
- created_at (TIMESTAMP)

-- جدول حلقات المسلسلات
episodes:
- id (Primary Key)
- show_id (Foreign Key)
- season_number (INT)
- episode_number (INT)
- title (VARCHAR)
- description (TEXT)
- video_url (VARCHAR)
- duration (INT)
- is_premium (BOOLEAN)
- created_at (TIMESTAMP)

-- جدول المحتوى الرياضي
sports:
- id (Primary Key)
- title (VARCHAR)
- slug (VARCHAR)
- description (TEXT)
- poster_image (VARCHAR)
- video_url (VARCHAR)
- sport_type (VARCHAR)
- event_date (DATETIME)
- duration (INT)
- is_premium (BOOLEAN)
- view_count (INT)
- created_at (TIMESTAMP)

-- جدول البث المباشر
live_tv:
- id (Primary Key)
- channel_name (VARCHAR)
- slug (VARCHAR)
- description (TEXT)
- logo_image (VARCHAR)
- stream_url (VARCHAR)
- category (VARCHAR)
- is_active (BOOLEAN)
- is_premium (BOOLEAN)
- created_at (TIMESTAMP)
```

### جداول العلاقات والميزات
```sql
-- جدول علاقة الأفلام بالأنواع
movie_genres:
- movie_id (Foreign Key)
- genre_id (Foreign Key)

-- جدول علاقة الأفلام بطاقم العمل
movie_cast:
- movie_id (Foreign Key)
- cast_id (Foreign Key)
- role (VARCHAR)

-- جدول علاقة المسلسلات بالأنواع
show_genres:
- show_id (Foreign Key)
- genre_id (Foreign Key)

-- جدول علاقة المسلسلات بطاقم العمل
show_cast:
- show_id (Foreign Key)
- cast_id (Foreign Key)
- role (VARCHAR)

-- جدول قائمة المشاهدة
watchlist:
- id (Primary Key)
- user_id (Foreign Key)
- content_type (ENUM: movie, show, sport)
- content_id (INT)
- created_at (TIMESTAMP)

-- جدول تاريخ المشاهدة
watch_history:
- id (Primary Key)
- user_id (Foreign Key)
- content_type (ENUM: movie, episode, sport, live_tv)
- content_id (INT)
- watch_duration (INT) - in seconds
- total_duration (INT) - in seconds
- last_position (INT) - in seconds
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

-- جدول أكواد الخصم
coupons:
- id (Primary Key)
- code (VARCHAR, UNIQUE)
- discount_percentage (DECIMAL)
- max_uses (INT)
- used_count (INT)
- valid_from (DATETIME)
- valid_until (DATETIME)
- is_active (BOOLEAN)
- created_at (TIMESTAMP)

-- جدول الصفحات الثابتة
pages:
- id (Primary Key)
- title (VARCHAR)
- slug (VARCHAR)
- content (TEXT)
- is_active (BOOLEAN)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

-- جدول الإعدادات العامة
settings:
- id (Primary Key)
- key (VARCHAR, UNIQUE)
- value (TEXT)
- type (ENUM: string, number, boolean, json)
- updated_at (TIMESTAMP)
```

## 2. هيكل التطبيق التقني

### الخلفية (Backend) - Flask
```
/backend/
├── app.py                 # التطبيق الرئيسي
├── config.py             # إعدادات التطبيق
├── requirements.txt      # المتطلبات
├── models/              # نماذج قاعدة البيانات
│   ├── __init__.py
│   ├── user.py
│   ├── content.py
│   ├── subscription.py
│   └── admin.py
├── routes/              # مسارات API
│   ├── __init__.py
│   ├── auth.py          # المصادقة
│   ├── content.py       # المحتوى
│   ├── user.py          # المستخدمين
│   ├── admin.py         # الإدارة
│   └── payment.py       # المدفوعات
├── utils/               # الأدوات المساعدة
│   ├── __init__.py
│   ├── auth.py          # مساعدات المصادقة
│   ├── payment.py       # مساعدات الدفع
│   └── video.py         # مساعدات الفيديو
├── static/              # الملفات الثابتة
│   ├── uploads/         # الملفات المرفوعة
│   └── assets/          # الأصول
└── templates/           # قوالب HTML (للإدارة)
```

### الواجهة الأمامية (Frontend) - React
```
/frontend/
├── public/
│   ├── index.html
│   ├── favicon.ico
│   └── manifest.json
├── src/
│   ├── components/      # المكونات القابلة لإعادة الاستخدام
│   │   ├── Header/
│   │   ├── Footer/
│   │   ├── VideoPlayer/
│   │   ├── ContentCard/
│   │   ├── SearchBar/
│   │   └── LoadingSpinner/
│   ├── pages/           # صفحات التطبيق
│   │   ├── Home/
│   │   ├── Movies/
│   │   ├── TVShows/
│   │   ├── Sports/
│   │   ├── LiveTV/
│   │   ├── Profile/
│   │   ├── Login/
│   │   └── Register/
│   ├── hooks/           # React Hooks مخصصة
│   │   ├── useAuth.js
│   │   ├── useVideo.js
│   │   └── useApi.js
│   ├── services/        # خدمات API
│   │   ├── api.js
│   │   ├── auth.js
│   │   ├── content.js
│   │   └── payment.js
│   ├── context/         # React Context
│   │   ├── AuthContext.js
│   │   └── ThemeContext.js
│   ├── utils/           # الأدوات المساعدة
│   │   ├── constants.js
│   │   ├── helpers.js
│   │   └── validators.js
│   ├── styles/          # ملفات التنسيق
│   │   ├── globals.css
│   │   ├── variables.css
│   │   └── components/
│   ├── App.js
│   ├── index.js
│   └── App.css
├── package.json
└── package-lock.json
```

## 3. تصميم واجهات المستخدم

### نظام الألوان
```css
:root {
  /* الألوان الأساسية */
  --primary-red: #e50914;
  --primary-dark: #141414;
  --secondary-dark: #1a1a1a;
  --accent-gold: #ffd700;
  
  /* ألوان النص */
  --text-primary: #ffffff;
  --text-secondary: #b3b3b3;
  --text-muted: #808080;
  
  /* ألوان الحالة */
  --success: #46d369;
  --warning: #ffc107;
  --error: #dc3545;
  --info: #17a2b8;
  
  /* ألوان التدرج */
  --gradient-primary: linear-gradient(135deg, #e50914 0%, #b20710 100%);
  --gradient-dark: linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.8) 100%);
}
```

### التايبوغرافي
```css
/* خطوط النظام */
--font-primary: 'Helvetica Neue', Arial, sans-serif;
--font-arabic: 'Cairo', 'Tajawal', sans-serif;

/* أحجام الخطوط */
--font-size-xs: 0.75rem;    /* 12px */
--font-size-sm: 0.875rem;   /* 14px */
--font-size-base: 1rem;     /* 16px */
--font-size-lg: 1.125rem;   /* 18px */
--font-size-xl: 1.25rem;    /* 20px */
--font-size-2xl: 1.5rem;    /* 24px */
--font-size-3xl: 1.875rem;  /* 30px */
--font-size-4xl: 2.25rem;   /* 36px */
```

### نقاط الكسر (Breakpoints)
```css
/* نقاط الكسر للتصميم المتجاوب */
--breakpoint-xs: 0;
--breakpoint-sm: 576px;
--breakpoint-md: 768px;
--breakpoint-lg: 992px;
--breakpoint-xl: 1200px;
--breakpoint-xxl: 1400px;
```

## 4. مكونات الواجهة الرئيسية

### الهيدر (Header)
- شعار الموقع
- قائمة التنقل الرئيسية
- شريط البحث
- أيقونة الاشتراك
- زر تسجيل الدخول/الملف الشخصي

### الصفحة الرئيسية
- سلايدر المحتوى المميز
- أقسام المحتوى المختلفة
- بطاقات المحتوى
- مساحات إعلانية

### صفحات المحتوى
- فلاتر البحث والتصفية
- شبكة عرض المحتوى
- ترقيم الصفحات
- خيارات الترتيب

### صفحة تفاصيل المحتوى
- صورة/فيديو المحتوى
- معلومات المحتوى
- مشغل الفيديو
- محتوى مشابه
- أزرار التفاعل

### الفوتر (Footer)
- روابط الصفحات المهمة
- وسائل التواصل الاجتماعي
- روابط التطبيقات
- حقوق النشر

## 5. ميزات التفاعل والحركة

### التأثيرات البصرية
- انتقالات سلسة بين الصفحات
- تأثيرات hover على البطاقات
- تحميل تدريجي للصور
- رسوم متحركة للأزرار

### التفاعلات المتقدمة
- تشغيل تلقائي للتريلر عند hover
- تحديث المحتوى بدون إعادة تحميل
- إشعارات فورية
- حفظ موضع المشاهدة

## 6. الأمان والأداء

### الأمان
- تشفير كلمات المرور
- حماية من SQL Injection
- حماية CSRF
- تحديد معدل الطلبات
- تشفير الاتصالات (HTTPS)

### الأداء
- ضغط الصور والفيديوهات
- تخزين مؤقت للمحتوى
- تحميل كسول للصور
- تحسين استعلامات قاعدة البيانات
- CDN للملفات الثابتة

