# دليل تشغيل مشروع بث الفيديو

## محتويات الملف المضغوط

يحتوي الملف المضغوط على:

### 📁 video-streaming-portal/ (الواجهة الأمامية)
- `src/` - ملفات المصدر الرئيسية
- `public/` - الملفات العامة
- `package.json` - تبعيات المشروع
- `vite.config.js` - إعدادات Vite
- `tailwind.config.js` - إعدادات Tailwind CSS
- `index.html` - الصفحة الرئيسية

### 📁 video_streaming_backend/ (الخلفية)
- `src/` - ملفات المصدر
  - `models/` - نماذج قاعدة البيانات
  - `routes/` - مسارات API
  - `main.py` - الملف الرئيسي
- `requirements.txt` - تبعيات Python

### 📄 ملفات التوثيق
- `final_documentation.md` - التوثيق النهائي الشامل
- `design_specifications.md` - مواصفات التصميم
- `reference_analysis.md` - تحليل الموقع المرجعي
- `test_report.md` - تقرير الاختبار
- `todo.md` - قائمة المهام المكتملة

## كيفية تشغيل المشروع

### 1. تشغيل الواجهة الأمامية

```bash
# الانتقال إلى مجلد الواجهة الأمامية
cd video-streaming-portal

# تثبيت التبعيات
npm install

# تشغيل خادم التطوير
npm run dev

# أو بناء المشروع للإنتاج
npm run build
```

### 2. تشغيل الخلفية

```bash
# الانتقال إلى مجلد الخلفية
cd video_streaming_backend

# إنشاء بيئة افتراضية
python -m venv venv

# تفعيل البيئة الافتراضية
# على Windows:
venv\Scripts\activate
# على macOS/Linux:
source venv/bin/activate

# تثبيت التبعيات
pip install -r requirements.txt

# تشغيل الخادم
python src/main.py
```

### 3. الوصول للموقع

- الواجهة الأمامية: http://localhost:5173
- API الخلفية: http://localhost:5000

## المتطلبات

### للواجهة الأمامية:
- Node.js (الإصدار 16 أو أحدث)
- npm أو yarn

### للخلفية:
- Python 3.8 أو أحدث
- pip

## الميزات المتاحة

✅ مشاهدة الأفلام والمسلسلات
✅ البث المباشر للقنوات
✅ مشغل فيديو متقدم
✅ نظام المستخدمين والمصادقة
✅ نظام الاشتراكات
✅ تصميم متجاوب

## الروابط المباشرة للموقع المنشور

- **الموقع**: https://opopdral.manus.space
- **API**: https://9yhyi3cq05k3.manus.space

## الدعم

لأي استفسارات أو مشاكل، يرجى مراجعة ملف `final_documentation.md` للحصول على معلومات مفصلة.

