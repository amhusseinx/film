import React from 'react';
import { Link } from 'react-router-dom';
import { Play, Star, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ContentCard = ({ item, type = 'movie' }) => {
  const {
    id,
    title,
    image,
    rating,
    year,
    duration,
    isPremium,
    isLive,
    genre,
  } = item;

  return (
    <div className="content-card group relative">
      <div className="relative overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button className="btn-primary">
            <Play className="h-4 w-4 ml-2" />
            {isLive ? 'مشاهدة مباشرة' : 'تشغيل'}
          </Button>
        </div>
        
        {/* Premium Badge */}
        {isPremium && (
          <div className="absolute top-2 right-2 bg-accent text-accent-foreground px-2 py-1 rounded text-xs font-bold">
            <Star className="h-3 w-3 inline ml-1" />
            مميز
          </div>
        )}
        
        {/* Live Badge */}
        {isLive && (
          <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-xs font-bold animate-pulse">
            🔴 مباشر
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-foreground mb-2 line-clamp-2">
          {title}
        </h3>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center space-x-2">
            {rating && (
              <span className="flex items-center">
                <Star className="h-3 w-3 text-accent ml-1" />
                {rating}
              </span>
            )}
            {year && (
              <span className="flex items-center">
                <Calendar className="h-3 w-3 ml-1" />
                {year}
              </span>
            )}
          </div>
          
          {duration && (
            <span className="flex items-center">
              <Clock className="h-3 w-3 ml-1" />
              {duration}
            </span>
          )}
        </div>
        
        {genre && (
          <div className="mt-2">
            <span className="genre-tag text-xs">{genre}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContentCard;

