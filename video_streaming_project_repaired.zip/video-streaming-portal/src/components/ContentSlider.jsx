
import React, { useEffect, useState } from 'react';

function ContentSlider() {
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await fetch('http://localhost:5000/api/content/movies', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        const data = await res.json();
        if (res.ok) {
          setMovies(data.movies || []);
        } else {
          setError(data.error || 'فشل في تحميل المحتوى');
        }
      } catch (err) {
        setError('خطأ في الاتصال بالخادم');
      }
    };

    fetchMovies();
  }, []);

  return (
    <div className="content-slider">
      <h3>الأفلام المقترحة</h3>
      {error && <p>{error}</p>}
      <div className="slider-container">
        {movies.map(movie => (
          <div key={movie.id} className="movie-card">
            <img src={movie.poster_image} alt={movie.title} />
            <h4>{movie.title}</h4>
            <p>{movie.description?.slice(0, 100)}...</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ContentSlider;
