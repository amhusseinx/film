
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

function AdminMovieForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const [movie, setMovie] = useState({
    title: '', slug: '', description: '', poster_image: '', banner_image: '',
    trailer_url: '', language_id: '', is_premium: false,
    video_url: '', duration: '', release_date: '', imdb_rating: '', age_rating: ''
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const token = localStorage.getItem('token');

  useEffect(() => {
    if (isEdit) {
      fetch(`http://localhost:5000/api/admin/movies`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
        .then(res => res.json())
        .then(data => {
          const target = data.find(m => m.id === parseInt(id));
          if (target) setMovie(target);
        });
    }
  }, [id, isEdit, token]);

  const handleChange = e => {
    const { name, value, type, checked } = e.target;
    setMovie(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = isEdit
      ? `http://localhost:5000/api/admin/movies/${id}`
      : `http://localhost:5000/api/admin/movies`;
    const method = isEdit ? 'PUT' : 'POST';
    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(movie)
      });
      if (res.ok) navigate('/admin/movies');
      else {
        const data = await res.json();
        setError(data.error || 'فشل العملية');
      }
    } catch {
      setError('فشل الاتصال بالخادم');
    }
  };

  return (
    <div>
      <h2>{isEdit ? 'تعديل فيلم' : 'إضافة فيلم جديد'}</h2>
      {error && <p>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input name="title" value={movie.title} onChange={handleChange} placeholder="العنوان" required />
        <input name="slug" value={movie.slug} onChange={handleChange} placeholder="slug" required />
        <input name="poster_image" value={movie.poster_image} onChange={handleChange} placeholder="رابط صورة" />
        <input name="banner_image" value={movie.banner_image} onChange={handleChange} placeholder="رابط بانر" />
        <input name="trailer_url" value={movie.trailer_url} onChange={handleChange} placeholder="رابط إعلان" />
        <textarea name="description" value={movie.description} onChange={handleChange} placeholder="الوصف" />
        <input name="language_id" value={movie.language_id} onChange={handleChange} placeholder="ID اللغة" />
        <input type="checkbox" name="is_premium" checked={movie.is_premium} onChange={handleChange} /> مميز؟
        <input name="video_url" value={movie.video_url} onChange={handleChange} placeholder="رابط الفيديو" />
        <input name="duration" value={movie.duration} onChange={handleChange} placeholder="المدة (بالدقائق)" />
        <input name="release_date" value={movie.release_date} onChange={handleChange} placeholder="تاريخ الإصدار" />
        <input name="imdb_rating" value={movie.imdb_rating} onChange={handleChange} placeholder="IMDB" />
        <input name="age_rating" value={movie.age_rating} onChange={handleChange} placeholder="الفئة العمرية" />
        <button type="submit">{isEdit ? 'تحديث' : 'إضافة'}</button>
      </form>
    </div>
  );
}

export default AdminMovieForm;
