import React, { useState } from 'react';
import ContentCard from '../components/ContentCard';
import heroBg from '../assets/hero-bg.jpg';

const TVShows = () => {
  // Mock data for TV shows
  const tvShows = Array.from({ length: 20 }, (_, i) => ({
    id: i + 1,
    title: `مسلسل ${i + 1}`,
    image: heroBg,
    rating: (Math.random() * 3 + 7).toFixed(1),
    year: 2024 - Math.floor(Math.random() * 5),
    duration: `${Math.floor(Math.random() * 30 + 30)}m`,
    genre: ['دراما', 'كوميديا', 'إثارة', 'خيال علمي', 'تاريخي'][Math.floor(Math.random() * 5)],
    isPremium: Math.random() > 0.5,
  }));

  return (
    <div className="pt-16">
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">المسلسلات</h1>
          <p className="text-muted-foreground">
            استمتع بأفضل المسلسلات والعروض التلفزيونية
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="content-grid">
          {tvShows.map((show) => (
            <ContentCard key={show.id} item={show} type="show" />
          ))}
        </div>
      </div>
    </div>
  );
};

export default TVShows;

