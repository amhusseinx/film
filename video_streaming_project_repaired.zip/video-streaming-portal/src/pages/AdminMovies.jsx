
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

function AdminMovies() {
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState('');

  const fetchMovies = async () => {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch('http://localhost:5000/api/admin/movies', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (res.ok) {
        setMovies(data);
      } else {
        setError(data.error || 'فشل في تحميل الأفلام');
      }
    } catch {
      setError('خطأ في الاتصال بالخادم');
    }
  };

  const deleteMovie = async (id) => {
    const token = localStorage.getItem('token');
    if (!window.confirm('هل أنت متأكد من حذف هذا الفيلم؟')) return;
    try {
      const res = await fetch(`http://localhost:5000/api/admin/movies/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        setMovies(movies.filter(movie => movie.id !== id));
      }
    } catch {
      alert('فشل الحذف');
    }
  };

  useEffect(() => {
    fetchMovies();
  }, []);

  return (
    <div>
      <h2>إدارة الأفلام</h2>
      <Link to="/admin/movies/new">➕ إضافة فيلم جديد</Link>
      {error && <p>{error}</p>}
      <table>
        <thead>
          <tr>
            <th>العنوان</th>
            <th>النوع</th>
            <th>التاريخ</th>
            <th>الإجراءات</th>
          </tr>
        </thead>
        <tbody>
          {movies.map(movie => (
            <tr key={movie.id}>
              <td>{movie.title}</td>
              <td>{movie.content_type}</td>
              <td>{movie.release_date?.split('T')[0]}</td>
              <td>
                <Link to={`/admin/movies/edit/${movie.id}`}>✏️ تعديل</Link>
                {' | '}
                <button onClick={() => deleteMovie(movie.id)}>🗑 حذف</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AdminMovies;
