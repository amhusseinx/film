import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Play, Plus, Star, Calendar, Clock, Users, Share2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import VideoPlayer from '../components/VideoPlayer';
import ContentSlider from '../components/ContentSlider';
import heroBg from '../assets/hero-bg.jpg';

const MovieDetails = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [watchProgress, setWatchProgress] = useState(0);
  const [relatedMovies, setRelatedMovies] = useState([]);
  const [isInWatchlist, setIsInWatchlist] = useState(false);

  useEffect(() => {
    // Mock movie data - in real app, fetch from API
    const mockMovie = {
      id: parseInt(id),
      title: `فيلم رقم ${id}`,
      description: 'قصة مثيرة ومليئة بالأحداث الشيقة والمغامرات الرائعة. يحكي الفيلم عن بطل يواجه تحديات كبيرة في رحلته للوصول إلى هدفه النبيل. مع مؤثرات بصرية مذهلة وأداء تمثيلي رائع من نجوم السينما.',
      poster_image: heroBg,
      banner_image: heroBg,
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      trailer_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      rating: 8.5,
      year: 2024,
      duration: '2h 15m',
      genre: 'أكشن، مغامرة، إثارة',
      language: 'العربية',
      director: 'أحمد محمد',
      cast: ['محمد علي', 'فاطمة أحمد', 'عمر حسن', 'نور الدين'],
      age_rating: '+13',
      is_premium: true,
      view_count: 1250000,
      release_date: '2024-01-15'
    };

    setMovie(mockMovie);

    // Mock related movies
    const mockRelated = Array.from({ length: 8 }, (_, i) => ({
      id: i + 10,
      title: `فيلم مشابه ${i + 1}`,
      image: heroBg,
      rating: (Math.random() * 3 + 7).toFixed(1),
      year: 2024,
      duration: `${Math.floor(Math.random() * 60 + 90)}m`,
      is_premium: Math.random() > 0.5,
    }));

    setRelatedMovies(mockRelated);
  }, [id]);

  const handlePlay = () => {
    setIsPlaying(true);
  };

  const handleTimeUpdate = (currentTime, duration) => {
    const progress = (currentTime / duration) * 100;
    setWatchProgress(progress);
  };

  const handleVideoEnded = () => {
    setIsPlaying(false);
    setWatchProgress(100);
  };

  const toggleWatchlist = () => {
    setIsInWatchlist(!isInWatchlist);
    // In real app, make API call to add/remove from watchlist
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: movie.title,
        text: movie.description,
        url: window.location.href,
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('تم نسخ الرابط');
    }
  };

  const handleDownload = () => {
    // In real app, initiate download or show download options
    alert('سيتم بدء التحميل قريباً');
  };

  if (!movie) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="pt-16">
      {/* Video Player Section */}
      {isPlaying ? (
        <div className="relative h-screen bg-black">
          <VideoPlayer
            src={movie.video_url}
            poster={movie.poster_image}
            title={movie.title}
            onTimeUpdate={handleTimeUpdate}
            onEnded={handleVideoEnded}
            autoPlay={true}
          />
          <Button
            onClick={() => setIsPlaying(false)}
            className="absolute top-4 right-4 z-50"
            variant="outline"
          >
            العودة
          </Button>
        </div>
      ) : (
        <>
          {/* Hero Section */}
          <section 
            className="relative h-[70vh] bg-cover bg-center"
            style={{ backgroundImage: `url(${movie.banner_image})` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
            <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
              <div className="max-w-2xl text-white">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="bg-accent text-accent-foreground px-3 py-1 rounded text-sm font-bold">
                    ⭐ {movie.rating}
                  </span>
                  <span className="bg-muted text-muted-foreground px-3 py-1 rounded text-sm">
                    {movie.age_rating}
                  </span>
                  {movie.is_premium && (
                    <span className="bg-primary text-primary-foreground px-3 py-1 rounded text-sm font-bold">
                      <Star className="h-3 w-3 inline ml-1" />
                      مميز
                    </span>
                  )}
                </div>

                <h1 className="text-4xl md:text-6xl font-bold mb-4">{movie.title}</h1>
                
                <div className="flex items-center space-x-6 text-sm mb-6">
                  <span className="flex items-center">
                    <Calendar className="h-4 w-4 ml-1" />
                    {movie.year}
                  </span>
                  <span className="flex items-center">
                    <Clock className="h-4 w-4 ml-1" />
                    {movie.duration}
                  </span>
                  <span className="flex items-center">
                    <Users className="h-4 w-4 ml-1" />
                    {movie.view_count.toLocaleString()} مشاهدة
                  </span>
                </div>

                <p className="text-lg leading-relaxed mb-8 max-w-xl">
                  {movie.description}
                </p>

                <div className="flex items-center space-x-4">
                  <Button onClick={handlePlay} className="btn-primary text-lg px-8 py-3">
                    <Play className="h-5 w-5 ml-2" />
                    مشاهدة الآن
                  </Button>
                  
                  <Button 
                    onClick={toggleWatchlist}
                    variant="outline" 
                    className="text-lg px-8 py-3"
                  >
                    <Plus className="h-5 w-5 ml-2" />
                    {isInWatchlist ? 'إزالة من القائمة' : 'إضافة للقائمة'}
                  </Button>

                  <Button onClick={handleShare} variant="ghost" size="lg">
                    <Share2 className="h-5 w-5" />
                  </Button>

                  <Button onClick={handleDownload} variant="ghost" size="lg">
                    <Download className="h-5 w-5" />
                  </Button>
                </div>

                {/* Progress Bar */}
                {watchProgress > 0 && (
                  <div className="mt-6">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span>تقدم المشاهدة</span>
                      <span>{Math.round(watchProgress)}%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: `${watchProgress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* Movie Details */}
          <div className="container mx-auto px-4 py-12">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-2">
                {/* Synopsis */}
                <section className="mb-12">
                  <h2 className="section-title">القصة</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    {movie.description}
                  </p>
                </section>

                {/* Cast & Crew */}
                <section className="mb-12">
                  <h2 className="section-title">طاقم العمل</h2>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold mb-2">الإخراج</h3>
                      <p className="text-muted-foreground">{movie.director}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">التمثيل</h3>
                      <p className="text-muted-foreground">{movie.cast.join('، ')}</p>
                    </div>
                  </div>
                </section>

                {/* Trailer */}
                <section className="mb-12">
                  <h2 className="section-title">الإعلان التشويقي</h2>
                  <div className="aspect-video bg-black rounded-lg overflow-hidden">
                    <VideoPlayer
                      src={movie.trailer_url}
                      poster={movie.poster_image}
                      title={`إعلان ${movie.title}`}
                    />
                  </div>
                </section>
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="bg-card rounded-lg p-6 sticky top-24">
                  <h3 className="font-semibold mb-4">معلومات الفيلم</h3>
                  <div className="space-y-4">
                    <div>
                      <span className="text-muted-foreground">النوع:</span>
                      <span className="mr-2">{movie.genre}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">اللغة:</span>
                      <span className="mr-2">{movie.language}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">تاريخ الإصدار:</span>
                      <span className="mr-2">{movie.release_date}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">المدة:</span>
                      <span className="mr-2">{movie.duration}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">التقييم:</span>
                      <span className="mr-2">{movie.rating}/10</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">التصنيف العمري:</span>
                      <span className="mr-2">{movie.age_rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Related Movies */}
            <section className="mt-16">
              <h2 className="section-title">أفلام مشابهة</h2>
              <ContentSlider items={relatedMovies} />
            </section>
          </div>
        </>
      )}
    </div>
  );
};

export default MovieDetails;

