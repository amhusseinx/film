import React from 'react';
import ContentCard from '../components/ContentCard';
import heroBg from '../assets/hero-bg.jpg';

const Sports = () => {
  // Mock data for sports content
  const sportsContent = Array.from({ length: 16 }, (_, i) => ({
    id: i + 1,
    title: `محتوى رياضي ${i + 1}`,
    image: heroBg,
    rating: (Math.random() * 3 + 7).toFixed(1),
    year: 2024,
    duration: `${Math.floor(Math.random() * 60 + 60)}m`,
    genre: ['كرة القدم', 'كرة السلة', 'التنس', 'السباحة', 'الجري'][Math.floor(Math.random() * 5)],
    isPremium: Math.random() > 0.5,
  }));

  return (
    <div className="pt-16">
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">الرياضة</h1>
          <p className="text-muted-foreground">
            تابع أفضل الأحداث والمباريات الرياضية
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="content-grid">
          {sportsContent.map((content) => (
            <ContentCard key={content.id} item={content} type="sport" />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Sports;

