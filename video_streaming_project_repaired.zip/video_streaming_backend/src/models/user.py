from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

# Create db instance here to avoid circular imports
db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    profile_image = db.Column(db.String(255))
    subscription_plan_id = db.Column(db.Integer, db.ForeignKey('subscription_plans.id'))
    device_limit = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    subscription_plan = db.relationship('SubscriptionPlan', backref='users')
    transactions = db.relationship('Transaction', backref='user', lazy=True)
    watchlist = db.relationship('Watchlist', backref='user', lazy=True)
    watch_history = db.relationship('WatchHistory', backref='user', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'profile_image': self.profile_image,
            'subscription_plan_id': self.subscription_plan_id,
            'device_limit': self.device_limit,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Watchlist(db.Model):
    __tablename__ = 'watchlist'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content_type = db.Column(db.Enum('movie', 'show', 'sport', 'live_tv'), nullable=False)
    content_id = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class WatchHistory(db.Model):
    __tablename__ = 'watch_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content_type = db.Column(db.Enum('movie', 'episode', 'sport', 'live_tv'), nullable=False)
    content_id = db.Column(db.Integer, nullable=False)
    watch_duration = db.Column(db.Integer, default=0)  # in seconds
    total_duration = db.Column(db.Integer, default=0)  # in seconds
    last_position = db.Column(db.Integer, default=0)   # in seconds
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

