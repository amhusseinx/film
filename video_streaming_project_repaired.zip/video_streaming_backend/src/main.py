import os
from dotenv import load_dotenv
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
load_dotenv()
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from src.models.user import db, User, Watchlist, WatchHistory
from src.models.content import Content, Movie, TVShow, Episode, Sport, LiveTV, Genre, Language, CastCrew
from src.models.subscription import SubscriptionPlan, Transaction, PaymentMethod
from src.routes.user import user_bp
from src.routes.content import content_bp
from src.routes.auth import auth_bp
from src.routes.subscription import subscription_bp
from src.routes.admin import admin_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'video_streaming_secret_key_2024'
app.config['JWT_SECRET_KEY'] = 'secure_jwt_secret_2024'

jwt = JWTManager(app)

# Enable CORS for all routes
CORS(app, origins="*")

# Register blueprints
app.register_blueprint(admin_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(user_bp, url_prefix='/api/users')
app.register_blueprint(content_bp, url_prefix='/api/content')
app.register_blueprint(subscription_bp, url_prefix='/api/subscription')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create tables
with app.app_context():
    db.create_all()
    
    # Create sample data if tables are empty
    if SubscriptionPlan.query.count() == 0:
        # Create subscription plans
        basic_plan = SubscriptionPlan(
            name='الخطة الأساسية',
            price=9.99,
            duration_days=30,
            device_limit=1,
            features='{"hd_quality": false, "download": false, "ads": true}'
        )
        premium_plan = SubscriptionPlan(
            name='الخطة المميزة',
            price=19.99,
            duration_days=30,
            device_limit=3,
            features='{"hd_quality": true, "download": true, "ads": false}'
        )
        platinum_plan = SubscriptionPlan(
            name='الخطة البلاتينية',
            price=29.99,
            duration_days=30,
            device_limit=5,
            features='{"hd_quality": true, "download": true, "ads": false, "4k": true}'
        )
        
        db.session.add_all([basic_plan, premium_plan, platinum_plan])
        db.session.commit()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

@app.route('/api/health')
def health_check():
    return {'status': 'healthy', 'message': 'Video Streaming API is running'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

