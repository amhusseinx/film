
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db

admin_bp = Blueprint('admin', __name__)

def admin_only():
    user_info = get_jwt_identity()
    if user_info["role"] != "admin":
        return False
    return True

@admin_bp.route('/admin/users', methods=['GET'])
@jwt_required()
def get_all_users():
    if not admin_only():
        return jsonify({'error': 'غير مصرح'}), 403
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@admin_bp.route('/admin/users/<int:user_id>', methods=['DELETE'])
@jwt_required()
def delete_user(user_id):
    if not admin_only():
        return jsonify({'error': 'غير مصرح'}), 403
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return jsonify({'message': 'تم حذف المستخدم'}), 200


from src.models.content import Content, Movie

@admin_bp.route('/admin/movies', methods=['GET'])
@jwt_required()
def get_movies():
    if not admin_only():
        return jsonify({'error': 'غير مصرح'}), 403
    movies = db.session.query(Content, Movie).join(Movie, Content.id == Movie.content_id).all()
    result = []
    for content, movie in movies:
        item = movie.to_dict()
        result.append(item)
    return jsonify(result)

@admin_bp.route('/admin/movies', methods=['POST'])
@jwt_required()
def add_movie():
    if not admin_only():
        return jsonify({'error': 'غير مصرح'}), 403
    data = request.get_json()
    content = Content(
        title=data['title'],
        slug=data['slug'],
        description=data.get('description'),
        poster_image=data.get('poster_image'),
        banner_image=data.get('banner_image'),
        trailer_url=data.get('trailer_url'),
        content_type='movie',
        language_id=data.get('language_id'),
        is_premium=data.get('is_premium', False)
    )
    db.session.add(content)
    db.session.flush()
    movie = Movie(
        content_id=content.id,
        video_url=data.get('video_url'),
        duration=data.get('duration'),
        release_date=data.get('release_date'),
        imdb_rating=data.get('imdb_rating'),
        age_rating=data.get('age_rating')
    )
    db.session.add(movie)
    db.session.commit()
    return jsonify({'message': 'تمت إضافة الفيلم', 'movie': movie.to_dict()}), 201

@admin_bp.route('/admin/movies/<int:movie_id>', methods=['PUT'])
@jwt_required()
def update_movie(movie_id):
    if not admin_only():
        return jsonify({'error': 'غير مصرح'}), 403
    movie = Movie.query.get_or_404(movie_id)
    content = movie.content
    data = request.get_json()
    content.title = data.get('title', content.title)
    content.slug = data.get('slug', content.slug)
    content.description = data.get('description', content.description)
    content.poster_image = data.get('poster_image', content.poster_image)
    content.banner_image = data.get('banner_image', content.banner_image)
    content.trailer_url = data.get('trailer_url', content.trailer_url)
    content.language_id = data.get('language_id', content.language_id)
    content.is_premium = data.get('is_premium', content.is_premium)

    movie.video_url = data.get('video_url', movie.video_url)
    movie.duration = data.get('duration', movie.duration)
    movie.release_date = data.get('release_date', movie.release_date)
    movie.imdb_rating = data.get('imdb_rating', movie.imdb_rating)
    movie.age_rating = data.get('age_rating', movie.age_rating)

    db.session.commit()
    return jsonify({'message': 'تم التحديث بنجاح', 'movie': movie.to_dict()})

@admin_bp.route('/admin/movies/<int:movie_id>', methods=['DELETE'])
@jwt_required()
def delete_movie(movie_id):
    if not admin_only():
        return jsonify({'error': 'غير مصرح'}), 403
    movie = Movie.query.get_or_404(movie_id)
    content = movie.content
    db.session.delete(movie)
    db.session.delete(content)
    db.session.commit()
    return jsonify({'message': 'تم حذف الفيلم'}), 200
