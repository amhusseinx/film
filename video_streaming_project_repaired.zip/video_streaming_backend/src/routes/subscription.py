from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.subscription import db, SubscriptionPlan, Transaction, PaymentMethod
from src.models.user import User
import uuid
import datetime

subscription_bp = Blueprint('subscription', __name__)

@subscription_bp.route('/plans'
@jwt_required(), methods=['GET'])
def get_subscription_plans():
    try:
        plans = SubscriptionPlan.query.filter_by(is_active=True).all()
        
        # If no plans exist, create default ones
        if not plans:
            basic_plan = SubscriptionPlan(
                name='الخطة الأساسية',
                price=9.99,
                duration_days=30,
                device_limit=1,
                features='{"hd_quality": false, "download": false, "ads": true, "content_access": "basic"}'
            )
            premium_plan = SubscriptionPlan(
                name='الخطة المميزة',
                price=19.99,
                duration_days=30,
                device_limit=3,
                features='{"hd_quality": true, "download": true, "ads": false, "content_access": "premium"}'
            )
            platinum_plan = SubscriptionPlan(
                name='الخطة البلاتينية',
                price=29.99,
                duration_days=30,
                device_limit=5,
                features='{"hd_quality": true, "download": true, "ads": false, "4k": true, "content_access": "all"}'
            )
            
            db.session.add_all([basic_plan, premium_plan, platinum_plan])
            db.session.commit()
            
            plans = [basic_plan, premium_plan, platinum_plan]
        
        plans_data = [plan.to_dict() for plan in plans]
        
        return jsonify({'plans': plans_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@subscription_bp.route('/subscribe'
@jwt_required(), methods=['POST'])
def subscribe():
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        plan_id = data.get('plan_id')
        payment_method = data.get('payment_method', 'credit_card')
        
        if not user_id or not plan_id:
            return jsonify({'error': 'معرف المستخدم ومعرف الخطة مطلوبان'}), 400
        
        # Verify user exists
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        # Verify plan exists
        plan = SubscriptionPlan.query.get(plan_id)
        if not plan or not plan.is_active:
            return jsonify({'error': 'خطة الاشتراك غير موجودة أو غير متاحة'}), 404
        
        # Create transaction
        transaction_id = str(uuid.uuid4())
        transaction = Transaction(
            user_id=user_id,
            subscription_plan_id=plan_id,
            amount=plan.price,
            payment_method=payment_method,
            transaction_id=transaction_id,
            status='completed'  # In real app, this would be 'pending' until payment is processed
        )
        
        # Update user subscription
        user.subscription_plan_id = plan_id
        user.device_limit = plan.device_limit
        
        db.session.add(transaction)
        db.session.commit()
        
        return jsonify({
            'message': 'تم الاشتراك بنجاح',
            'transaction': transaction.to_dict(),
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@subscription_bp.route('/user/<int:user_id>/subscription'
@jwt_required(), methods=['GET'])
def get_user_subscription(user_id):
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        # Get current subscription
        current_transaction = Transaction.query.filter_by(
            user_id=user_id,
            status='completed'
        ).order_by(Transaction.created_at.desc()).first()
        
        subscription_data = {
            'user_id': user_id,
            'current_plan': user.subscription_plan.to_dict() if user.subscription_plan else None,
            'device_limit': user.device_limit,
            'is_active': user.is_active
        }
        
        if current_transaction:
            subscription_data.update({
                'start_date': current_transaction.start_date.isoformat() if current_transaction.start_date else None,
                'end_date': current_transaction.end_date.isoformat() if current_transaction.end_date else None,
                'is_expired': current_transaction.end_date < datetime.datetime.utcnow() if current_transaction.end_date else False
            })
        
        return jsonify({'subscription': subscription_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@subscription_bp.route('/user/<int:user_id>/transactions'
@jwt_required(), methods=['GET'])
def get_user_transactions(user_id):
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        transactions = Transaction.query.filter_by(user_id=user_id).order_by(
            Transaction.created_at.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)
        
        transactions_data = [transaction.to_dict() for transaction in transactions.items]
        
        return jsonify({
            'transactions': transactions_data,
            'total': transactions.total,
            'page': page,
            'per_page': per_page,
            'pages': transactions.pages
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@subscription_bp.route('/payment-methods'
@jwt_required(), methods=['GET'])
def get_payment_methods():
    try:
        # Return mock payment methods
        payment_methods = [
            {
                'id': 1,
                'name': 'بطاقة ائتمان',
                'type': 'credit_card',
                'is_active': True,
                'processing_fee': 0.0
            },
            {
                'id': 2,
                'name': 'بطاقة خصم',
                'type': 'debit_card',
                'is_active': True,
                'processing_fee': 0.0
            },
            {
                'id': 3,
                'name': 'PayPal',
                'type': 'paypal',
                'is_active': True,
                'processing_fee': 2.9
            },
            {
                'id': 4,
                'name': 'تحويل بنكي',
                'type': 'bank_transfer',
                'is_active': True,
                'processing_fee': 1.0
            }
        ]
        
        return jsonify({'payment_methods': payment_methods}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@subscription_bp.route('/cancel'
@jwt_required(), methods=['POST'])
def cancel_subscription():
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'معرف المستخدم مطلوب'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        # Set user to basic plan (plan ID 1)
        user.subscription_plan_id = 1
        user.device_limit = 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'تم إلغاء الاشتراك بنجاح',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

