from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required

subscription_bp = Blueprint('subscription', __name__)

@subscription_bp.route('/plans', methods=['GET'])
@jwt_required()
def get_plans():
    return jsonify({"plans": ["basic", "premium", "vip"]})